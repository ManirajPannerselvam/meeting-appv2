create table if not exists finance_transactions (

    transaction_id uuid primary key,

    transaction_date date not null,

    transaction_type text not null,

    category text not null,

    description text,

    amount numeric(14,2) not null,

    payment_method text,

    reference_no text,

    created_by uuid references profiles(id),

    created_at timestamptz default now()

);