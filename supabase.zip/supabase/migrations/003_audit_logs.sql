-- ============================================================
-- AUDIT LOGS
-- ============================================================
-- Stores application-level audit history.
--
-- Depends on:
--   public.profiles(id)
-- ============================================================

create table if not exists public.audit_logs (
    id bigint generated always as identity primary key,

    user_id uuid references public.profiles(id) on delete set null,

    action text,
    module text,
    record_id text,
    description text,

    old_data jsonb,
    new_data jsonb,

    ip_address text,
    user_agent text,

    created_at timestamptz not null default now()
);

-- ============================================================
-- INDEXES
-- ============================================================

create index if not exists idx_audit_logs_user
    on public.audit_logs(user_id);

create index if not exists idx_audit_logs_created
    on public.audit_logs(created_at desc);

create index if not exists idx_audit_logs_module
    on public.audit_logs(module);

create index if not exists idx_audit_logs_action
    on public.audit_logs(action);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table public.audit_logs enable row level security;

-- ============================================================
-- ADMIN READ POLICY
-- ============================================================
-- Admin users can view audit history.
--
-- This assumes profiles.role contains the application role.
-- Adjust the role values if your roles migration uses different
-- names.
-- ============================================================

drop policy if exists "Admins can view audit logs"
on public.audit_logs;

create policy "Admins can view audit logs"
on public.audit_logs
for select
to authenticated
using (
    exists (
        select 1
        from public.profiles p
        where p.id = auth.uid()
          and p.role = 'admin'
    )
);

-- ============================================================
-- INSERT POLICY
-- ============================================================
-- Authenticated users may create audit entries.
-- ============================================================

drop policy if exists "Authenticated users can create audit logs"
on public.audit_logs;

create policy "Authenticated users can create audit logs"
on public.audit_logs
for insert
to authenticated
with check (
    user_id = auth.uid()
    or user_id is null
);