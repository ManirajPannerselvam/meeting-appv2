create or replace function current_financial_year()

returns text

language sql

as $$

select

case

when extract(month from now()) >= 4

then

extract(year from now())::text ||

'-' ||

(extract(year from now())+1)::text

else

(extract(year from now())-1)::text ||

'-' ||

extract(year from now())::text

end;

$$;