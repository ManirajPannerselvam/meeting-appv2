create table if not exists roles (

    id bigint generated always as identity primary key,

    role_name text unique not null,

    description text,

    permissions jsonb not null default '[]',

    created_at timestamptz default now()

);