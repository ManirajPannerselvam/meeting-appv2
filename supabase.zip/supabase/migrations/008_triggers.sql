-- ===========================================
-- UPDATED_AT TRIGGER FUNCTION
-- ===========================================

create or replace function update_updated_at()

returns trigger

language plpgsql

as $$

begin

	new.updated_at = now();

	return new;

end;

$$;

-- ===========================================
-- UPDATED_AT TRIGGERS
-- ===========================================

create trigger trg_profiles_updated

before update

on profiles

for each row

execute function update_updated_at();

create trigger trg_system_settings_updated

before update

on system_settings

for each row

execute function update_updated_at();

-- ===========================================
-- CREATE PROFILE AFTER SIGNUP
-- ===========================================

create or replace function handle_new_user()

returns trigger

language plpgsql

security definer

set search_path = public

as $$

begin

	insert into profiles (

		id,

		email,

		full_name,

		role

	)

	values (

		new.id,

		new.email,

		coalesce(

			new.raw_user_meta_data ->> 'full_name',

			''

		),

		'Staff'

	)

	on conflict (id)

	do nothing;

	return new;

end;

$$;

drop trigger if exists

on_auth_user_created

on auth.users;

create trigger on_auth_user_created

after insert

on auth.users

for each row

execute function handle_new_user();