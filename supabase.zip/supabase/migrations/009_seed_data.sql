-- ===========================================
-- DEFAULT ROLES
-- ===========================================

insert into roles (role_name, description, permissions)
values
(
    'SuperAdmin',
    'Full system access',
    '["*"]'::jsonb
),
(
    'Admin',
    'Administrative access',
    '[
        "dashboard",
        "reports",
        "finance",
        "analytics",
        "workflow",
        "users",
        "roles",
        "settings"
    ]'::jsonb
),
(
    'Manager',
    'Department management',
    '[
        "dashboard",
        "reports",
        "workflow",
        "analytics"
    ]'::jsonb
),
(
    'Accountant',
    'Finance management',
    '[
        "dashboard",
        "finance",
        "reports"
    ]'::jsonb
),
(
    'Staff',
    'Standard staff access',
    '[
        "dashboard",
        "workflow"
    ]'::jsonb
),
(
    'Viewer',
    'Read only',
    '[
        "dashboard"
    ]'::jsonb
)
on conflict (role_name) do nothing;

-- ===========================================
-- SYSTEM SETTINGS
-- ===========================================

insert into system_settings (key, value)
values
(
    'application',
    '{
        "name":"Temple Operations Reporting System",
        "version":"1.0.0",
        "timezone":"Asia/Kolkata"
    }'::jsonb
),
(
    'finance',
    '{
        "currency":"INR",
        "financial_year":"April-March"
    }'::jsonb
),
(
    'meeting',
    '{
        "default_duration":60,
        "reminder_minutes":15
    }'::jsonb
)
on conflict (key) do nothing;