-- ============================================================
-- Temple Operations Reporting System
-- Database      : Template Database
-- Migration No. : 010
-- File Name     : 010_seed.sql
-- Author        : Your Name
-- Created       : YYYY-MM-DD
-- ============================================================
-- PURPOSE
--   Seed initial application data.
--
-- DESCRIPTION
--   Inserts the minimum required data so the application
--   can run after deployment. This file should be safe to
--   execute multiple times (idempotent).
--
-- DEPENDS ON
--   001_extensions.sql
--   002_templates.sql
--   003_daily_reports.sql
--   004_indexes.sql
--   005_rls.sql
--   006_triggers.sql
--   007_rpc.sql
--   008_views.sql
--   009_audit.sql
--
-- TABLES
--   public.templates
--
-- NOTES
--   - Initial data only.
--   - No schema changes.
--   - No indexes.
--   - No RLS.
--   - No triggers.
-- ============================================================

BEGIN;

-- 1. Dictionary Version

-- 2. Default Template

-- 3. Sample Stations

-- 4. Sample Fields

-- 5. Default Application Settings

-- 6. Development/Test Data (Optional)

-- 7. Comments

COMMIT;