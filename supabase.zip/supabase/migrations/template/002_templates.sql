-- ============================================================
-- Temple Operations Reporting System
-- Database      : Template Database
-- Migration No. : 002
-- File Name     : 002_templates.sql
-- ============================================================
-- PURPOSE
--   Create the templates table.
--
-- DESCRIPTION
--   Stores report template definitions.
--   Uses JSONB for dynamic station configuration.
--   Supports template versioning.
--
-- DEPENDS ON
--   001_extensions.sql
--
-- TABLE
--   public.templates
--
-- ============================================================

BEGIN;

-- ============================================================
-- 1. CREATE TABLE
-- ============================================================

create table if not exists public.templates (

    template_id uuid primary key
        default gen_random_uuid(),

    template_name text not null,

    template_code text,

    template_type text,

    category text,

    department text,

    description text,

    station_keys jsonb not null
        default '{}'::jsonb,

    fields jsonb not null
        default '[]'::jsonb,

    metadata jsonb not null
        default '{}'::jsonb,

    dict_version integer not null
        default 1,

    version integer not null
        default 1,

    is_active boolean not null
        default true,

    created_by uuid,

    created_at timestamptz not null
        default now(),

    updated_at timestamptz not null
        default now()
);

-- ============================================================
-- 2. CONSTRAINTS
-- ============================================================

alter table public.templates
    add constraint templates_template_name_check
    check (length(trim(template_name)) > 0);

alter table public.templates
    add constraint templates_dict_version_check
    check (dict_version > 0);

alter table public.templates
    add constraint templates_version_check
    check (version > 0);

-- ============================================================
-- 3. UNIQUE INDEXES
-- ============================================================

create unique index if not exists
    idx_templates_template_code_unique
on public.templates(template_code)
where template_code is not null;

create index if not exists
    idx_templates_template_name
on public.templates(template_name);

create index if not exists
    idx_templates_category
on public.templates(category);

create index if not exists
    idx_templates_department
on public.templates(department);

create index if not exists
    idx_templates_type
on public.templates(template_type);

create index if not exists
    idx_templates_active
on public.templates(is_active);

create index if not exists
    idx_templates_created_at
on public.templates(created_at desc);

-- ============================================================
-- 4. COMMENTS
-- ============================================================

comment on table public.templates is
    'Template definitions for the Temple Operations Reporting System.';

comment on column public.templates.template_id is
    'Unique template identifier.';

comment on column public.templates.template_name is
    'Human-readable template name.';

comment on column public.templates.template_code is
    'Optional unique business/template code.';

comment on column public.templates.station_keys is
    'JSONB station configuration and station key definitions.';

comment on column public.templates.fields is
    'JSONB dynamic field definitions used by the template.';

comment on column public.templates.metadata is
    'Additional template metadata.';

comment on column public.templates.dict_version is
    'Version of the application dictionary used for compressed report keys.';

comment on column public.templates.version is
    'Template definition version.';

-- ============================================================
-- 5. ROW LEVEL SECURITY
-- ============================================================

alter table public.templates enable row level security;

-- ============================================================
-- 6. UPDATED_AT TRIGGER FUNCTION
-- ============================================================

create or replace function public.set_templates_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists trg_templates_updated_at
on public.templates;

create trigger trg_templates_updated_at
before update on public.templates
for each row
execute function public.set_templates_updated_at();

COMMIT;