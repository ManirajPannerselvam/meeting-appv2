-- ============================================================
-- Temple Operations Reporting System
-- Database      : Template Database
-- Migration No. : 008
-- File Name     : 008_views.sql
-- Author        : Your Name
-- Created       : YYYY-MM-DD
-- ============================================================
-- PURPOSE
--   Create database views for reporting and dashboards.
--
-- DESCRIPTION
--   Provides reusable read-only views for dashboards,
--   analytics and exports without duplicating SQL queries.
--
-- DEPENDS ON
--   001_extensions.sql
--   002_templates.sql
--   003_daily_reports.sql
--   004_indexes.sql
--   005_rls.sql
--   006_triggers.sql
--   007_rpc.sql
--
-- TABLES
--   public.templates
--   public.daily_reports
--
-- NOTES
--   - Views only.
--   - No tables.
--   - No indexes.
--   - No triggers.
--   - No RPC functions.
-- ============================================================

BEGIN;

-- 1. Active Templates View

-- 2. Daily Reports View

-- 3. User Reports View

-- 4. Today's Reports View

-- 5. Dashboard Summary View

-- 6. Report Statistics View

-- 7. Template Usage View

-- 8. Export View (CSV/PDF)

-- 9. Comments

COMMIT;