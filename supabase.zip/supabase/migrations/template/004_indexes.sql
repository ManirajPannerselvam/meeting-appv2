-- ============================================================
-- Temple Operations Reporting System
-- Database      : Template Database
-- Migration No. : 004
-- File Name     : 004_indexes.sql
-- Author        : Your Name
-- Created       : YYYY-MM-DD
-- ============================================================
-- PURPOSE
--   Create indexes for high-performance reporting.
--
-- DESCRIPTION
--   Adds B-Tree, Composite, Partial and JSONB indexes
--   to improve read performance for dashboards,
--   reporting, filtering and searching.
--
-- DEPENDS ON
--   001_extensions.sql
--   002_templates.sql
--   003_daily_reports.sql
--
-- TABLES
--   public.templates
--   public.daily_reports
--
-- NOTES
--   - Do not create tables.
--   - Do not create RLS.
--   - Do not create triggers.
--   - Indexes only.
-- ============================================================

BEGIN;

-- 1. Template Indexes

-- 2. Daily Report Indexes

-- 3. Composite Indexes

-- 4. JSONB GIN Indexes

-- 5. Partial Indexes

-- 6. Search (pg_trgm) Indexes

-- 7. Comments

COMMIT;