-- ============================================================
-- Temple Operations Reporting System
-- Database      : Operations / Reporting Database
-- Migration No. : 003
-- File Name     : 003_daily_reports.sql
-- ============================================================
-- PURPOSE
--   Create the daily_reports table.
--
-- DESCRIPTION
--   Stores one daily operational report per:
--     User + Date + Shift + Template
--
--   Dynamic station/report values are stored in JSONB so that
--   new stations and fields do not require schema migrations.
--
-- SCALABILITY
--   Designed as the logical reporting table for large-scale
--   reporting. Indexes, partitioning and archival can be added
--   independently without changing the JSONB report structure.
--
-- DEPENDS ON
--   profiles
--   templates
--
-- TABLE
--   public.daily_reports
-- ============================================================

BEGIN;

-- ============================================================
-- 1. TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS public.daily_reports (

    -- Report identity
    report_date date NOT NULL,

    shift text NOT NULL,

    template_id uuid NOT NULL,

    user_id uuid NOT NULL,

    -- Dynamic station/report payload
    stations jsonb NOT NULL DEFAULT '{}'::jsonb,

    -- Report lifecycle
    status text NOT NULL DEFAULT 'draft',

    -- Synchronization support
    client_updated_at timestamptz,

    -- Server timestamps
    created_at timestamptz NOT NULL DEFAULT now(),

    updated_at timestamptz NOT NULL DEFAULT now(),

    -- Soft-delete support for synchronization
    deleted_at timestamptz

);

-- ============================================================
-- 2. PRIMARY KEY
-- ============================================================

ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_pkey;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_pkey
PRIMARY KEY (
    report_date,
    shift,
    template_id,
    user_id
);

-- ============================================================
-- 3. FOREIGN KEYS
-- ============================================================

-- User/profile ownership
ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_user_id_fkey;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_user_id_fkey
FOREIGN KEY (user_id)
REFERENCES public.profiles(id)
ON DELETE RESTRICT;

-- Template ownership
ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_template_id_fkey;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_template_id_fkey
FOREIGN KEY (template_id)
REFERENCES public.templates(id)
ON DELETE RESTRICT;

-- ============================================================
-- 4. REPORT COLUMNS
-- ============================================================

COMMENT ON COLUMN public.daily_reports.report_date
IS 'Operational reporting date.';

COMMENT ON COLUMN public.daily_reports.shift
IS 'Operational shift identifier.';

COMMENT ON COLUMN public.daily_reports.template_id
IS 'Template used to generate this report.';

COMMENT ON COLUMN public.daily_reports.user_id
IS 'User who owns/submitted the report.';

-- ============================================================
-- 5. JSONB REPORT DATA
-- ============================================================

COMMENT ON COLUMN public.daily_reports.stations
IS 'Dynamic station and field values defined by the selected template.';

-- ============================================================
-- 6. STATUS
-- ============================================================

ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_status_check;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_status_check
CHECK (
    status IN (
        'draft',
        'submitted',
        'approved',
        'rejected',
        'archived'
    )
);

-- ============================================================
-- 7. TIMESTAMP / SYNC COLUMNS
-- ============================================================

COMMENT ON COLUMN public.daily_reports.client_updated_at
IS 'Timestamp supplied by the offline client for synchronization.';

COMMENT ON COLUMN public.daily_reports.updated_at
IS 'Server-side timestamp of the latest modification.';

COMMENT ON COLUMN public.daily_reports.deleted_at
IS 'Soft-delete timestamp used for synchronization and retention workflows.';

-- ============================================================
-- 8. DEFAULTS
-- ============================================================

ALTER TABLE public.daily_reports
ALTER COLUMN stations SET DEFAULT '{}'::jsonb;

ALTER TABLE public.daily_reports
ALTER COLUMN status SET DEFAULT 'draft';

ALTER TABLE public.daily_reports
ALTER COLUMN created_at SET DEFAULT now();

ALTER TABLE public.daily_reports
ALTER COLUMN updated_at SET DEFAULT now();

-- ============================================================
-- 9. CHECK CONSTRAINTS
-- ============================================================

ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_stations_object_check;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_stations_object_check
CHECK (
    jsonb_typeof(stations) = 'object'
);

ALTER TABLE public.daily_reports
DROP CONSTRAINT IF EXISTS daily_reports_shift_not_empty_check;

ALTER TABLE public.daily_reports
ADD CONSTRAINT daily_reports_shift_not_empty_check
CHECK (
    length(trim(shift)) > 0
);

-- ============================================================
-- 10. COMMENTS
-- ============================================================

COMMENT ON TABLE public.daily_reports
IS 'Template-driven daily operational reports using JSONB station data.';

-- ============================================================
-- 11. INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_daily_reports_date
ON public.daily_reports(report_date DESC);

CREATE INDEX IF NOT EXISTS idx_daily_reports_user
ON public.daily_reports(user_id);

CREATE INDEX IF NOT EXISTS idx_daily_reports_template
ON public.daily_reports(template_id);

CREATE INDEX IF NOT EXISTS idx_daily_reports_updated
ON public.daily_reports(updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_daily_reports_status
ON public.daily_reports(status);

-- Useful for offline synchronization
CREATE INDEX IF NOT EXISTS idx_daily_reports_sync
ON public.daily_reports(updated_at DESC, user_id);

-- ============================================================
-- 12. UPDATED_AT TRIGGER FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION public.set_daily_reports_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_daily_reports_updated_at
ON public.daily_reports;

CREATE TRIGGER trg_daily_reports_updated_at
BEFORE UPDATE ON public.daily_reports
FOR EACH ROW
EXECUTE FUNCTION public.set_daily_reports_updated_at();

COMMIT;