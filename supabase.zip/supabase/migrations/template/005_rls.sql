-- ============================================================
-- Temple Operations Reporting System
-- Database      : Template Database
-- Migration No. : 005
-- File Name     : 005_rls.sql
-- Author        : Your Name
-- Created       : YYYY-MM-DD
-- ============================================================
-- PURPOSE
--   Configure Row Level Security (RLS).
--
-- DESCRIPTION
--   Enables Row Level Security for all reporting tables.
--   Defines SELECT, INSERT, UPDATE and DELETE policies.
--   Ensures users can access only their authorized data.
--
-- DEPENDS ON
--   001_extensions.sql
--   002_templates.sql
--   003_daily_reports.sql
--   004_indexes.sql
--
-- TABLES
--   public.templates
--   public.daily_reports
--
-- NOTES
--   - Enable RLS.
--   - Create SELECT policies.
--   - Create INSERT policies.
--   - Create UPDATE policies.
--   - Create DELETE policies.
--   - Service Role bypass.
--   - Uses auth.uid().
-- ============================================================

BEGIN;

-- 1. Enable Row Level Security

-- 2. Templates Policies
--    SELECT
--    INSERT
--    UPDATE
--    DELETE

-- 3. Daily Reports Policies
--    SELECT
--    INSERT
--    UPDATE
--    DELETE

-- 4. Service Role Policies

-- 5. Comments

COMMIT;