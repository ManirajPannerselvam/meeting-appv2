create table if not exists profiles (

    id uuid primary key references auth.users(id) on delete cascade,

    email text not null,

    full_name text,

    role text not null default 'Staff',

    department text,

    phone text,

    avatar_url text,

    is_active boolean default true,

    created_at timestamptz default now(),

    updated_at timestamptz default now()

);

create index if not exists idx_profiles_role

on profiles(role);

create index if not exists idx_profiles_department

on profiles(department);