-- ===========================================
-- ENABLE RLS
-- ===========================================

alter table profiles enable row level security;

alter table roles enable row level security;

alter table audit_logs enable row level security;

alter table finance_transactions enable row level security;

alter table notifications enable row level security;

alter table system_settings enable row level security;

-- ===========================================
-- PROFILES
-- ===========================================

create policy "Users can view own profile"

on profiles

for select

using (

	auth.uid() = id

);

create policy "Users can update own profile"

on profiles

for update

using (

	auth.uid() = id

);

-- ===========================================
-- FINANCE
-- ===========================================

create policy "Authenticated users read finance"

on finance_transactions

for select

to authenticated

using (true);

create policy "Authenticated users insert finance"

on finance_transactions

for insert

to authenticated

with check (

	auth.uid() = created_by

);

create policy "Owner updates finance"

on finance_transactions

for update

to authenticated

using (

	auth.uid() = created_by

);

create policy "Owner deletes finance"

on finance_transactions

for delete

to authenticated

using (

	auth.uid() = created_by

);

-- ===========================================
-- AUDIT LOGS
-- ===========================================

create policy "Users view own audit logs"

on audit_logs

for select

to authenticated

using (

	auth.uid() = user_id

);

create policy "System inserts audit logs"

on audit_logs

for insert

to authenticated

with check (true);

-- ===========================================
-- NOTIFICATIONS
-- ===========================================

create policy "Users view own notifications"

on notifications

for select

to authenticated

using (

	auth.uid() = user_id

);

create policy "Users update own notifications"

on notifications

for update

to authenticated

using (

	auth.uid() = user_id

);

-- ===========================================
-- SYSTEM SETTINGS
-- ===========================================

create policy "Authenticated users read settings"

on system_settings

for select

to authenticated

using (true);