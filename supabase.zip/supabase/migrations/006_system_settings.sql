create table if not exists system_settings (

    key text primary key,

    value jsonb,

    updated_at timestamptz default now()

);